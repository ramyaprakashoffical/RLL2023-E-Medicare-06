package com.medicare;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.cart.Cart;
import com.medicare.cart.CartRepository;
import com.medicare.cart.CartService;


@SpringBootTest
public class CartTest {
	@Autowired
	CartService cs;
	@Autowired 
	CartRepository cr;

	@Test
	@DisplayName("GET Cart details")
	public void getallcartTest(){

	    List<Cart> as = cs.getCart();
	 double rs =as.size();
	 assertTrue(rs>0);

	}
	

	@Test
	@DisplayName("Delete Medicine")
	public void deletecarttest() {
	Cart ce =new Cart();
	ce.setMedicineId(9);
	cs.deleteCart(9);
	assertFalse(cr.existsById(ce.getMedicineId()));
	}   
}
