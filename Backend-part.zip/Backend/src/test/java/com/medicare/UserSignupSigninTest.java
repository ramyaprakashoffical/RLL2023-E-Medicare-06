package com.medicare;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.user.AuthenticationStatus;
import com.medicare.user.User;
import com.medicare.user.UserRepository;
import com.medicare.user.UserService;


@RunWith(Suite.class)
@SuiteClasses({})
@SpringBootTest
class UserSignupSigninTest {

	@Autowired
	UserService userService;
	
	@Autowired
	UserRepository userRepository;
	
	
/*	@Test
	@DisplayName("SignUp with valid details")
	public void signUpTest(){
		User user = new User();
		user.setFirst_name("Ramya");
		user.setLast_name("P");
		user.setMobile_no("9876543880");
		user.setAge(25);
		user.setUsername("ramya@gmail.com");
		user.setPassword("12345");
		user.setGender("Female");
		
		userService.insertUser(user);
	}   */
	
	@Test
	@DisplayName("SignIn with valid details")
	public void signInTest(){
		String username = "ramya@gmail.com";
		String password = "12345";
		
		AuthenticationStatus res = userService.getStatus(username, password);
	}

}
